package net.corda.explorer.exception;

public class FlowsNotFoundException extends Exception{

    public FlowsNotFoundException(String message) {
        super(message);
    }
}
