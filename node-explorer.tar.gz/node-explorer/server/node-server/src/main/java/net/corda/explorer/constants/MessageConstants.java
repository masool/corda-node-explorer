package net.corda.explorer.constants;

public class MessageConstants {

    public static String SUCCESS = "SUCCESS";
}
