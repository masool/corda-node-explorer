package net.corda.explorer.model.response;

import java.util.List;

public class PartyList {
    private List<String> parties;
}
