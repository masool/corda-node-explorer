First Run:

Terminal:1
1) npm install
2) cd ./server && ./gradlew bootJar, move compiled jar in ./server/build/libs to the root.
3) java -jar explorer-server-0.1.0.jar

Terminal 2:
1) npm run electron

secone run:
Terminal1:
java -jar explorer-server-0.1.0.jar

Terminal2:
npm run electron # will launch corda-node-explorer

Connect explorer to nodes:

Terminal1:
1) Goto Project root Directory and run command --> workflows-kotlin/build/nodes/runnodes
2) Start explorer following instructions as above mentioned in second run
3) After corda-node-Explorer launch give credentials as follows:
RPCHostname: localhost
RPCPort: 10005
RPCUsername: user1
RPCPassword: test

PartyA	PartyB	PartyC
10005	10009	10013
user1	user1	user1
test	test	test



got settings: copy path: /home/irfan/Downloads/explorer/corda-node-explorer/samples/cordapp-example/workflows-kotlin/build/libs
# Happy Learning...:)
